#ifndef TRANSMIT
#define TRANSMIT

#include <stdint.h>
#include "constants.h"

void transmit(int * bits, uint16_t * output, params_t * params);

#endif